1) cd ..\hw3
2) python cli.py